package ar.org.centro8.especialidades.web.intefaces.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@Entity
@Table(name="alumnos")
public class Alumno {
  
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(unique = true, nullable = false)
    private int id;
	private String nombre;
	private String apellido;
	private int edad;
    
    @ManyToOne
    @JoinColumn(name="id_Curso")
    private Curso curso;
    
    public Alumno() {
    }

    public Alumno(String nombre, String apellido, int edad, Curso curso) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.curso = curso;
    }

    public Alumno(int id, String nombre, String apellido, int edad, Curso curso) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.curso = curso;
    }
    
    
    
}
