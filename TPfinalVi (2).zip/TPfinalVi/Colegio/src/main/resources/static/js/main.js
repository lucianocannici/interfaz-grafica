function confirmarEliminacion(){
	return window.confirm("¿Está seguro que desea eliminar?")
}
